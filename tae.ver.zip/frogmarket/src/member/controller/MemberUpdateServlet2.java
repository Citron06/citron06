package member.controller;

import java.sql.Connection;
import java.sql.DriverManager;

public class MemberUpdateServlet2 {

	public static void main(String[] args) {
		
		
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "system";
		String password = "oracle";
		
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			Connection con = DriverManager.getConnection(url,user,password);
			System.out.println("연결성공");
			
			String name = "W";
			String job = "e";
			String sql = "UPDATE EMP SET ENAME=""++", 
		}
	
	}
}